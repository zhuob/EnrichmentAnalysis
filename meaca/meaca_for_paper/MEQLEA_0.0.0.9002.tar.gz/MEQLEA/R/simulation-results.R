
library(ggplot2)
library(reshape2)
#library(xtable)
library(dplyr)
library(gridExtra)
library(grid)


#' uniform qq-plot for type I error simulation.
#'
#' @title Uniform QQ-plot. 
#' @param data  simulated p-value matrix.
#' @param textsize, a vector of four, controlling the text size of legened, title, axis, axis.title, respectively 
#' @return a figure
#' @export
#' 
#' 

## maybe a qqplot would be better

qqTypeIerror <- function(data, textsize = rep(20, 4)){
  dat_new <- melt(data, value.name = "Pval", variable.name = "Method")

  A <- ggplot(dat_new) +
    stat_qq(aes(sample = Pval, colour = Method, linetype = Method), distribution=qunif, size = 1,
             geom = "line") + 
    geom_abline(slope = 1, intercept = 0) +
    theme(legend.position="top", 
          legend.text = element_text(size = textsize[1]),
          plot.title = element_text(size = textsize[2]),  
          strip.text.y = element_text(size = 8, colour = "black", face = "bold"),  # controls the facet_grid
          axis.text=element_text(size=textsize[3], face = "bold"), 
          axis.title=element_text(size=textsize[4],face="bold")) +
    guides(fill = guide_legend(keywidth = 0.8, keyheight = 1),
           linetype=guide_legend(keywidth = 3, keyheight = 1),
           colour=guide_legend(keywidth = 3, keyheight = 1))
  return (A)

}


#' Combines two qq plot in one figure and produce the legend in a separate figure.
#'
#' @title Uniform QQ-plot. 
#' @param dat1  simulated p-value matrix when DE % = 0.
#' @param dat2  simulated p-value matrix for DE % = 10%.
#' @param case which correlation structure to plot. 
#' @param legend if \code{TRUE}, plot the legend; otherwise just plot the qq-plot
#' @param textsize, a vector of four, controlling the text size of legened, title, axis, axis.title, respectively 
#' @return a figure
#' @export
#' 
#' 

ArrangeTypeIerror <- function(dat1, dat2, textsize = rep(20, 4), case,  legend= F){
# dat1:  p value matrix for type I error, without DE
# dat2: p value matrix for type I error, with DE
# legend is used for the last case, for all figures.    
  
  # this function is used to extract the legend
  g_legend<-function(a.gplot){
    tmp <- ggplot_gtable(ggplot_build(a.gplot))
    leg <- which(sapply(tmp$grobs, function(x) x$name) == "guide-box")
    legend <- tmp$grobs[[leg]]
    return(legend)}
  
  A1 <- qqTypeIerror(dat1,  textsize = textsize)
  A2 <- qqTypeIerror(dat2, textsize = textsize)
  
  if(legend){    # plot the legend in a separate figure
    mylegend<-g_legend(A1)
    p_fig <- grid.arrange(mylegend , nrow=2,heights=c(3, 1))
      }
  
    else{  ## arrange the plots 
      p_fig <- grid.arrange(arrangeGrob(A1 + theme(legend.position="none"),
                           A2 + theme(legend.position="none"),
                          nrow=1), 
                          nrow=2,   # one for the plot, and one for the label
                          heights=c(10, 1),
                          main=textGrob(paste("(", case, ")", sep =""), vjust= 1,hjust=0,
                                        gp=gpar(fontsize=20, fontface = "bold")))
    }
}
  


#' the recalibrated power
#'
#' @title calculate the revalibrated power 
#' @param data  simulated p-value matrix.
#' @param textsize, a vector of four, controlling the text size of legened, title, axis, axis.title, respectively 
#' @return a figure
#' @export
#' 
#' 
RecalibratePower <- function(data1, data2, alpha_level = 0.05, showcol = 1:8){
  ## data1: the type I error table
  ## data2: the corresponding power table
  ## alpha_level: what is the desired significance level 
  ## showcol:  choose the results from which methods you want to report
  data1 <- data1[, showcol]
  data2 <- data2[, showcol]
  adjusted_alpha <- sapply(data1, quantile, alpha_level)
  
  power <- se <- c()
  for ( i in 1: ncol(data1))
  {
    power[i] <- mean(data2[, i] < adjusted_alpha[i])
    se[i] <- sd(data2[, i] < adjusted_alpha[i])/sqrt(nrow(data2))
  }
  names(power) <- colnames(data1)
  names(adjusted_alpha) <- colnames(data1)
  names(se) <- colnames(data1)
  
  return(list(adjusted_alpha = adjusted_alpha, power = power, se = se))
}



#' the recalibrated power
#'
#' @title calculate the actual type I error for a nominal alpha 
#' @param data  simulated p-value matrix.
#' @param alpha, a vector or a numeric value that specifies the desired type I error
#' @return a matrix
#' @export
#' 
typeIerror_quantile <- function(data, alpha, showcol = 1){
  
  tf <- data < alpha
  results <- colMeans(tf)[showcol]
  results
}
  


### 
#' produce power for a given method.
#'
#' @title create the power table. 
#' @export
#' 

producePower <- function(size, setup, coln,  alpha_level= 0.05){
  ## size: the three levels, 0.05, 0.1, 0.2
  ## setup: has two levels, "A1", "A2"
  
  setwd("/Users/Bin/Google Drive/Study/Thesis/Correlation/Share/Simulation/SimulationPower20160211/")
  
  #case <- c("a0", "a", "c", "e", "f")
  case <- c("a", "b", "c", "d", "e")
  sim1 <- c("5VS0", "10VS0", "15VS0", "20VS0")
  sim2 <- c("15VS10", "20VS10", "25VS10", "30VS10")
  
  if (size == 0.05){folder <- "SizePoint05"}
  else if (size == 0.1){folder <- "SizePoint1"}
  else if (size == 0.2){folder <- "SizePoint2"}
  
  if (setup == "A1") {sim = sim1}
  else {sim = sim2}
  
  power <- matrix(NA, nrow = length(case), ncol = length(sim))
  for ( i in 1: length(case)){
    for (j in 1:length(sim)){
      file <- paste(folder, "/Power_", case[i], "_", sim[j], "PCT.txt", sep ="")
      data <- read.table(file, header=T)[, coln]
      power[i, j] <- mean(data < alpha_level)
    }
  }
  power <- data.frame(power)
  rownames(power) <- case
  colnames(power) <- sim
  return(power)
}




#' @title summerize power. 
#' @param data  simulated p-value matrix.
#' @param textsize, a vector of four, controlling the text size of legened, title, axis, axis.title, respectively 
#' @return a figure
#' @export
#' 
summarizePower<- function(folder, setup, coln, case){
   ## setup: has two levels, "A1", "A2"
  
  #  case <- c("a0", "a", "c", "e", "f", "g")
  sim1 <- c("5VS0", "10VS0", "15VS0", "20VS0")
  sim2 <- c("15VS10", "20VS10", "25VS10", "30VS10")
  
  if (setup == "A1") {sim = sim1}
  else {sim = sim2}
  
  file <- paste(folder, "/PowerMEQLEA_", case, "_", sim[1], "PCT.txt", sep ="")
  data <- read.table(file, header=T)[, coln]
  p_mat <- data.frame(matrix(NA, nrow = length(data), ncol = length(sim)))
  
  for (j in 1:length(sim)){
    file <- paste(folder, "/PowerMEQLEA_", case, "_", sim[j], "PCT.txt", sep ="")
   # print(file)
    data <- read.table(file, header=T)[, coln]
    p_mat[, j] <- data
  }
  colnames(p_mat) <- paste("S", 1:4, sep = "")

  
  
  p2 <- melt(p_mat, variable.name = "alternative", value.name = "p.value")
  p3 <-p2  %>%
    group_by(alternative) %>%
    summarize(n=n(), power=mean(p.value < 0.05),sd=sd(p.value < 0.05)) %>%
    mutate(se=sd/sqrt(n),LCI=power+qnorm(0.025)*se,UCI=power+qnorm(0.975)*se)
  p3$UCI[p3$UCI >1] = 1; p3$LCI[p3$LCI<0] =0;
  p3$case <- case
  
  return(p3)
  
}


#' @title Uniform QQ-plot. 
#' @param data  simulated p-value matrix.
#' @param textsize, a vector of four, controlling the text size of legened, title, axis, axis.title, respectively 
#' @return a figure
#' @export
#'
plotPower <- function(folder,  setup = "A1", showcol=1, textsize = rep(20, 4), xtext = c("DE percentage", "Power")){
  
  updated_case <- c("a", "b", "c", "d", "e")  ##  If I want to change the name of correlation structures
  
  r1 <- summarizePower(folder,  setup, coln=showcol, case = "a" )
 
  
  case <- c("b", "c", "d", "e")
  for (i in 1:length(case))
  {
    r2 <- summarizePower(folder, setup, coln=showcol, case = case[i] )
    r1 <- rbind(r1, r2)
  }
  
  r1$DEpct <- rep(c(0.05, 0.1, 0.15, 0.2), 5)
  r1$CorStruct[r1$case=="a"] <- updated_case[1]
  r1$CorStruct[r1$case=="b"] <- updated_case[2]
  r1$CorStruct[r1$case=="c"] <- updated_case[3]
  r1$CorStruct[r1$case=="d"] <- updated_case[4]
  r1$CorStruct[r1$case=="e"] <- updated_case[5]
  
  
  
  if (setup == "A2") {r1$DEpct <- r1$DEpct + 0.1}
  ggplot(r1, aes(x = as.factor(DEpct), y = power, group=case,  color = CorStruct, linetype = CorStruct)) +
    geom_errorbar(aes(ymin = LCI, ymax = UCI), width= 0.3, size =1) + 
    geom_line(size=0.8) + 
    geom_point(size = 0.8) +
    labs(x=xtext[1], y=xtext[2]) +
    theme(legend.position="top", 
          legend.text = element_text(size = textsize[1]),
          plot.title = element_text(size = textsize[2]), 
          axis.text=element_text(size=textsize[3]), 
          axis.title=element_text(size=textsize[4],face="bold")) +
    # scale_y_continuous(labels = percent)  +
    guides(fill = guide_legend(keywidth = 1, keyheight = 1),
           linetype=guide_legend(keywidth = 3, keyheight = 1),
           colour=guide_legend(keywidth = 3, keyheight = 1))
  
}




#' comparing power (not calibrated) of different methods
#' @title Uniform QQ-plot. 
#' @param data  simulated p-value matrix.
#' @param textsize, a vector of four, controlling the text size of legened, title, axis, axis.title, respectively 
#' @return a figure
# #' @export

powerDiffMethod <- function(rown, size, setup, alpha_level=0.05){
  # rown: specifies which case we want to compare
  # size: corresponds to the three folders
  # setup: whether the null is 10% or 0%  
  
  result <- data.frame(matrix(NA, nrow = 8, ncol = 4))
  for ( i in 1:8){
    result[i,] <- producePower(size, setup, coln = i, alpha_level = alpha_level)[rown, ]
  }
  p1 <- read.table("Power_a0_50_5VS0PCT.txt", header = T)
  powertable <- producePower(0.05, "A1", coln=1)[1:5, ]
  colnames(result) <- colnames(powertable)
  rownames(result) <- colnames(p1)
  return(result) 
  
}


#' the table in the power simulation 
#' @title create the calibrated power table . 
#' @param data  simulated p-value matrix.
#' @param textsize, a vector of four, controlling the text size of legened, title, axis, axis.title, respectively 
#' @return a figure
#' @export
#' 
createPowerTable <- function(folder, showcol, setup = "A1", case = "a"){
  
  pw <- "Power_"
  typeIer <- "TypeIerror_"
  t2 <-  c("5VS0PCT", "10VS0PCT", "15VS0PCT", "20VS0PCT"); row_name <- t2
  t3 <- "_0PCTforcalibration.txt"
  if (setup == "A2") {
    t2 <- c("15VS10PCT", "20VS10PCT", "25VS10PCT", "30VS10PCT")
    row_name <- t2
    t3 <- "_10PCTforcalibration.txt"
    }
 
  file1 <- paste(folder, "/", typeIer, case, t3, sep = "" )
  file2 <- paste(folder, "/", pw, case, "_", t2, ".txt", sep ="")
    
    dat1 <- read.table(file1, header=T)
    dat2 <- read.table(file2[1], header=T)
    power1 <- RecalibratePower(dat1, dat2, showcol = showcol)
    calib_power <- power1$power
    adjusted_alpha <- power1$adjusted_alpha
      
    for(i in 2:length(file2))
    {
      dat2 <- read.table(file2[i], header=T)
      power2 <-RecalibratePower(dat1, dat2, showcol = showcol)
      calib_power <- rbind(calib_power, power2$power)
    }
     rownames(calib_power) <- paste("S", 1:4, sep  = "")
     

  results <- cbind(adjusted_alpha, t(calib_power))
  return(results)  

  
}
  
  
